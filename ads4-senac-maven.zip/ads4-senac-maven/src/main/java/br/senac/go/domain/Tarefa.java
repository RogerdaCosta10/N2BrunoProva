package br.senac.go.domain;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "tarefa")
public class Tarefa extends BaseModel {

    @Column(length = 50, nullable = false)
    private String descricao;

    @Column(length = 50, nullable = false)
    private String responsavel;

    @ManyToOne(fetch = FetchType.LAZY)
    private Usuario usuario;

}
