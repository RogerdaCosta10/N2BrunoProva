package br.senac.go.resources;


import br.senac.go.domain.Tarefa;

import br.senac.go.generics.GenericOperationsResource;
import br.senac.go.services.TarefaService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

@RestController //Fala que o controlador vai trabalhar com REST
@RequestMapping(path = "/tarefa")
@Api(value="Operações para manipulação dos dados do tarefa",
        tags = "tarefa ")
public class TarefaResource implements
        GenericOperationsResource<Tarefa, Integer> {

    @Autowired
    private TarefaService tarefaService;

    //Outro exemplo de fazer injeção de dependência sem usar @Autowired
    /*public tarefaResource(tarefaService tarefaService){
        this.tarefaService = tarefaService;
    }*/

    private static final Logger LOGGER =
            Logger.getLogger(TarefaResource.class.getName());

    /**
     * Consumes é o que o serviço vai receber (json ou xml)
     * Produces é o que o serviço vai entregar (json ou xml)
     * @param entity
     * @return
     */
    @Override
    @PostMapping(consumes = {MediaType.APPLICATION_JSON_VALUE,
            "application/xml;charset=UTF-8"},
    produces = {MediaType.APPLICATION_JSON_VALUE,
    MediaType.APPLICATION_XML_VALUE})
    @ApiOperation(value="${resource.tarefa-post}",
            notes="Criar dados de tarefa.")
    @ApiResponses(value={
            @ApiResponse(code = 200, message = "Requisição feita com sucesso.", response = Tarefa.class),
            @ApiResponse(code = 201, message = "Registro criado com sucesso.", response = Tarefa.class),
            @ApiResponse(code = 204, message = "O servidor processou a solicitação com sucesso e não está retornando nenhum conteúdo."),
            @ApiResponse(code = 301, message = "Redirecionamento permanente.", response = Tarefa.class),
            @ApiResponse(code = 401, message = "Não autorizado.", response = Tarefa.class),
            @ApiResponse(code = 404, message = "Registro não encontrado.", response = Tarefa.class),
            @ApiResponse(code = 500, message = "Erro na requisão, verifique configurações do servidor.", response = Tarefa.class)
    })
    public Tarefa post(@RequestBody @Validated Tarefa entity) {
        LOGGER.log(Level.INFO,"tarefaResource.post inicado {} ", entity);

        Tarefa tarefaPersitida = this.tarefaService.create(entity);

        LOGGER.log(Level.INFO,"tarefaResource.post concluído {} ", tarefaPersitida);
        return tarefaPersitida;
    }

    @Override
    @GetMapping(produces = {MediaType.APPLICATION_JSON_VALUE,
            MediaType.APPLICATION_XML_VALUE})
    public List<Tarefa> get() {

        LOGGER.log(Level.INFO,"Exemplo do GET:");
        return null;
    }

    @Override
    @PutMapping(value = "/{id}",
            consumes = {MediaType.APPLICATION_JSON_VALUE})
    public void put(@RequestBody @Validated Tarefa entity,
                    @PathVariable("id") Integer id) {
        LOGGER.log(Level.INFO,
                String.format("Exemplo do PUT: %s | %d", entity, id));

        this.tarefaService.updatePut(entity, id);

    }

    @Override
    @PatchMapping(value = "/{id}",
            consumes = {MediaType.APPLICATION_JSON_VALUE})
    public void patch(@RequestBody @Validated Tarefa entity,
                      @PathVariable("id") Integer id) throws Exception {
        LOGGER.log(Level.INFO,
                String.format("Exemplo do PATCH: %s | %d", entity, id));

        this.tarefaService.updatePatch(entity, id);

    }

    @Override
    @DeleteMapping(consumes = {MediaType.APPLICATION_JSON_VALUE})
    public void delete(@RequestBody @Validated Tarefa entity) {
        LOGGER.log(Level.INFO,
                String.format("Exemplo do DELETE: %s", entity));
    }

    @Override
    @DeleteMapping(value="/{id}")
    public void deleteById(@PathVariable("id") Integer id) {
        LOGGER.log(Level.INFO,
                String.format("Exemplo do DELETE: %d", id));
    }
}
