package br.senac.go.repositories;

import br.senac.go.domain.Pessoa;
import br.senac.go.domain.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Integer> {

    //List<Pessoa> findPessoaByNomeAndAndDataInicioOrDataFimAndContatos();
    List<Usuario> findPessoasByNomeLikeIgnoreCase(String nome);
}
