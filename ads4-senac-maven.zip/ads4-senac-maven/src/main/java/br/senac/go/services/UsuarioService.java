package br.senac.go.services;

import br.senac.go.domain.Usuario;
import br.senac.go.domain.Usuario;
import br.senac.go.generics.IService;
import br.senac.go.repositories.UsuarioRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
@Slf4j
public class UsuarioService implements IService<Usuario, Integer> {

    /**
     * @Autowired fazer a injeção de dependênciada classe
     */
    @Autowired
    private UsuarioRepository usuarioRepository;

    @Override
    @Transactional
    public Usuario create(Usuario entity) {

        log.info("Método UsuarioService.create invocado");
        log.debug("Valores informados UsuarioService.create {}", entity);

        return this.usuarioRepository.save(entity);
    }

    @Override
    public Usuario readById(Integer id) throws Exception {
        log.info("Método UsuarioService.readById invocado");
        log.debug("Valores informados UsuarioService.readById {}", id);

        Usuario Usuario = this.usuarioRepository
                .findById(id)
                .orElseThrow(() -> new Exception("Registro não encontrado."));

        log.debug("Valores recuperados em UsuarioService.readById são {}", Usuario);
        return Usuario;
    }

    @Override
    public Usuario read(Usuario entity) throws Exception {

        log.info("Método UsuarioService.read invocado");
        log.debug("Valores informados UsuarioService.read {}", entity);

        Example<Usuario> UsuarioAprocurar = Example.of(entity);
        Usuario Usuario = this.usuarioRepository
                .findOne(UsuarioAprocurar)
                .orElseThrow(() -> new Exception("Registro não encontrado."));

        log.debug("Valores recuperados em UsuarioService.read são {}", Usuario);

        return Usuario;
    }

    @Override
    @Transactional
    public Usuario updatePatch(Usuario entity, Integer id) throws Exception {
        log.info("Método UsuarioService.updatePatch invocado");
        log.debug("Valores informados UsuarioService.updatePatch {} {}", entity, id);

        /*//Exemplo 1 para persistir dados sem utilizar mapper(automático)
        //Encontrar o registro - Neste contexto o objeto UsuarioEncontrado tem vínculo
        //com o hibernate.Logo ele é um objeto ATACHADO;
        Usuario UsuarioEncontrada = this.readById(id);
        //Atualiza os registros
        UsuarioEncontrada.setNome(entity.getNome());
        UsuarioEncontrada.setDataInicio(entity.getDataInicio());
        UsuarioEncontrada.setDataFim(entity.getDataFim());
        UsuarioEncontrada.setContatos(entity.getContatos());

        //Persistir no banco de dados
        this.UsuarioRepository.save(UsuarioEncontrada);


        //Exemplo 2, é possível fazer o gravar o objeto no banco, porém temos um erro.
        //O erro está relacionado a confiança no usuário, onde o usuário obrigatoriamente
        //precisda informar um ID que já esteja no banco de dados
        //Caso seja um novo 'id', será criado um novo registro. Não haverá uma atualização.
        entity.setId(id);
        this.UsuarioRepository.save(entity);
        */

        /**
         *  Exemplo 3, para evitar a situação do exemplo 2, precisamos seguir os seguintes passos:
         *  1. Fazer uma pesquisa para verificar se o ID existe
         *  2. Se existir, fazer a atualização.
         */

       boolean registroEncontrado = this.usuarioRepository.findById(id).isPresent();
       Usuario UsuarioAtualizada;

       if(registroEncontrado) {
           entity.setId(id);
           UsuarioAtualizada = this.usuarioRepository.save(entity);
       }
       else {
           log.error("Error: UsuarioService.updatePatch ao atualizar registro: {} {}",
                   entity, id);
           throw new Exception("Erro ao atualizar regitro");
       }


        log.debug("Valores atualizados em UsuarioService.updatePatch são {}", UsuarioAtualizada);

        return UsuarioAtualizada;
    }

    @Override
    @Transactional
    public Usuario updatePut(Usuario entity, Integer id) {
        log.info("Método UsuarioService.updatePatch invocado");
        log.debug("Valores informados UsuarioService.updatePatch {} {}", entity, id);

        log.debug("Valores recuperados em UsuarioService.read são {}", entity);

        return null;
    }

    @Override
    @Transactional
    public Usuario deleteById(Integer id) {
        return null;
    }

    @Override
    @Transactional
    public Usuario delete(Usuario entity) {
        return null;
    }
}
