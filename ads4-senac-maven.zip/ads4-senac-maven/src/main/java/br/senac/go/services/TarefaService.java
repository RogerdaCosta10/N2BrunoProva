package br.senac.go.services;

import br.senac.go.domain.Tarefa;
import br.senac.go.domain.Tarefa;
import br.senac.go.generics.IService;
import br.senac.go.repositories.TarefaRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
@Slf4j
public class TarefaService implements IService<Tarefa, Integer> {

    /**
     * @Autowired fazer a injeção de dependênciada classe
     */
    @Autowired
    private TarefaRepository TarefaRepository;

    @Override
    @Transactional
    public Tarefa create(Tarefa entity) {

        log.info("Método TarefaService.create invocado");
        log.debug("Valores informados TarefaService.create {}", entity);

        return this.TarefaRepository.save(entity);
    }

    @Override
    public Tarefa readById(Integer id) throws Exception {
        log.info("Método TarefaService.readById invocado");
        log.debug("Valores informados TarefaService.readById {}", id);

        Tarefa Tarefa = this.TarefaRepository
                .findById(id)
                .orElseThrow(() -> new Exception("Registro não encontrado."));

        log.debug("Valores recuperados em TarefaService.readById são {}", Tarefa);
        return Tarefa;
    }

    @Override
    public Tarefa read(Tarefa entity) throws Exception {

        log.info("Método TarefaService.read invocado");
        log.debug("Valores informados TarefaService.read {}", entity);

        Example<Tarefa> TarefaAprocurar = Example.of(entity);
        Tarefa Tarefa = this.TarefaRepository
                .findOne(TarefaAprocurar)
                .orElseThrow(() -> new Exception("Registro não encontrado."));

        log.debug("Valores recuperados em TarefaService.read são {}", Tarefa);

        return Tarefa;
    }

    @Override
    @Transactional
    public Tarefa updatePatch(Tarefa entity, Integer id) throws Exception {
        log.info("Método TarefaService.updatePatch invocado");
        log.debug("Valores informados TarefaService.updatePatch {} {}", entity, id);

        /*//Exemplo 1 para persistir dados sem utilizar mapper(automático)
        //Encontrar o registro - Neste contexto o objeto TarefaEncontrado tem vínculo
        //com o hibernate.Logo ele é um objeto ATACHADO;
        Tarefa TarefaEncontrada = this.readById(id);
        //Atualiza os registros
        TarefaEncontrada.setNome(entity.getNome());
        TarefaEncontrada.setDataInicio(entity.getDataInicio());
        TarefaEncontrada.setDataFim(entity.getDataFim());
        TarefaEncontrada.setContatos(entity.getContatos());

        //Persistir no banco de dados
        this.TarefaRepository.save(TarefaEncontrada);


        //Exemplo 2, é possível fazer o gravar o objeto no banco, porém temos um erro.
        //O erro está relacionado a confiança no usuário, onde o usuário obrigatoriamente
        //precisda informar um ID que já esteja no banco de dados
        //Caso seja um novo 'id', será criado um novo registro. Não haverá uma atualização.
        entity.setId(id);
        this.TarefaRepository.save(entity);
        */

        /**
         *  Exemplo 3, para evitar a situação do exemplo 2, precisamos seguir os seguintes passos:
         *  1. Fazer uma pesquisa para verificar se o ID existe
         *  2. Se existir, fazer a atualização.
         */

       boolean registroEncontrado = this.TarefaRepository.findById(id).isPresent();
       Tarefa TarefaAtualizada;

       if(registroEncontrado) {
           entity.setId(id);
           TarefaAtualizada = this.TarefaRepository.save(entity);
       }
       else {
           log.error("Error: TarefaService.updatePatch ao atualizar registro: {} {}",
                   entity, id);
           throw new Exception("Erro ao atualizar regitro");
       }


        log.debug("Valores atualizados em TarefaService.updatePatch são {}", TarefaAtualizada);

        return TarefaAtualizada;
    }

    @Override
    @Transactional
    public Tarefa updatePut(Tarefa entity, Integer id) {
        log.info("Método TarefaService.updatePatch invocado");
        log.debug("Valores informados TarefaService.updatePatch {} {}", entity, id);

        log.debug("Valores recuperados em TarefaService.read são {}", entity);

        return null;
    }

    @Override
    @Transactional
    public Tarefa deleteById(Integer id) {
        return null;
    }

    @Override
    @Transactional
    public Tarefa delete(Tarefa entity) {
        return null;
    }
}
